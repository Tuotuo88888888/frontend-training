<template>
    <div>
        这是留言板
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>