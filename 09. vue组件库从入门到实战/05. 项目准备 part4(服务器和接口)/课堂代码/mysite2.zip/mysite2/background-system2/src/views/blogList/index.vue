<template>
    <div>
        文章列表
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>