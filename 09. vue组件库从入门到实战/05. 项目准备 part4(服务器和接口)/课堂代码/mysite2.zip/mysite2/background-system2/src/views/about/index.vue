<template>
    <div>
        关于
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>