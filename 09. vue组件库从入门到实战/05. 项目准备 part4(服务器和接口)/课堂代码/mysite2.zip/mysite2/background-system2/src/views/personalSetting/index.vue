<template>
    <div>
        个人设置
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>